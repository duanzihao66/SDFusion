# Ultralytics YOLO 🚀, AGPL-3.0 license

from ultralytics.yolo.v8 import detect,segment 

__all__ = 'detect''segment'
