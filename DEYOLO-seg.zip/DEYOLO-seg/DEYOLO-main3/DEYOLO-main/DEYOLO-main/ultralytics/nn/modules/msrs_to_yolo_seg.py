import cv2
import numpy as np
import os
from pathlib import Path

def get_msrs_classes():
    """MSRS数据集的类别映射（像素值 → 类别ID），需根据实际数据集调整"""
    return {
        0: 0,   # 背景
        1: 1,   # 建筑
        2: 2,   # 植被
        3: 3,   # 水体
        4: 4,   # 道路
        5: 5    # 其他
    }

def mask_to_yolo_seg(label_path, class_map, output_labels_dir, min_area=50, epsilon=0.005):
    """将单张MSRS分割标签转换为YOLO实例分割格式"""
    # 读取分割标签（单通道灰度图）
    label_img = cv2.imread(label_path, cv2.IMREAD_GRAYSCALE)
    if label_img is None:
        print(f"错误：无法读取标签 {label_path}")
        return

    height, width = label_img.shape
    base_name = os.path.splitext(os.path.basename(label_path))[0]
    output_txt_path = os.path.join(output_labels_dir, f"{base_name}.txt")

    with open(output_txt_path, 'w') as f:
        # 遍历每个类别
        for pixel_val, class_id in class_map.items():
            if class_id == 0:  # 跳过背景类别
                continue

            # 生成该类别的二值掩码
            mask = (label_img == pixel_val).astype(np.uint8) * 255
            if np.sum(mask) == 0:  # 无该类别像素，跳过
                continue

            # 查找连通组件（每个连通组件对应一个实例）
            num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)

            # 处理每个连通组件
            for i in range(1, num_labels):  # 索引从1开始（0是背景）
                x, y, w, h, area = stats[i]
                if area < min_area:  # 过滤小面积噪声
                    continue

                # 提取实例掩码
                instance_mask = (labels == i).astype(np.uint8) * 255

                # 查找实例轮廓
                contours, _ = cv2.findContours(instance_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                for contour in contours:
                    # 轮廓近似（减少点数，平衡精度与效率）
                    perimeter = cv2.arcLength(contour, True)
                    approx_contour = cv2.approxPolyDP(contour, epsilon * perimeter, True)

                    # 转换为坐标点列表
                    points = approx_contour.reshape(-1, 2).tolist()
                    if len(points) < 3:  # 点数不足，跳过（非有效轮廓）
                        continue

                    # 计算归一化边界框
                    x_center = (x + w / 2) / width
                    y_center = (y + h / 2) / height
                    box_width = w / width
                    box_height = h / height

                    # 归一化轮廓点
                    normalized_points = []
                    for px, py in points:
                        normalized_x = px / width
                        normalized_y = py / height
                        normalized_points.extend([normalized_x, normalized_y])

                    # 写入YOLO实例分割格式（类别ID + 边界框 + 轮廓点）
                    line_parts = [
                        str(class_id),
                        f"{x_center:.6f}", f"{y_center:.6f}",
                        f"{box_width:.6f}", f"{box_height:.6f}"
                    ]
                    line_parts.extend([f"{p:.6f}" for p in normalized_points])
                    f.write(" ".join(line_parts) + "\n")

def batch_convert_msrs_to_yolo_seg(msrs_labels_dir, output_labels_dir, class_map, min_area=50):
    """批量转换MSRS分割标签为YOLO实例分割格式"""
    os.makedirs(output_labels_dir, exist_ok=True)

    # 遍历所有分割标签文件（.png格式）
    for label_path in Path(msrs_labels_dir).glob("*.png"):
        mask_to_yolo_seg(
            str(label_path), 
            class_map, 
            output_labels_dir, 
            min_area=min_area
        )
        print(f"已转换：{label_path} → {output_labels_dir}/{label_path.stem}.txt")

if __name__ == "__main__":
    # ================== 配置路径 ==================
    MSRS_LABELS_DIR = "/path/to/msrs/labels"   # MSRS原始分割标签目录（含.png文件）
    OUTPUT_LABELS_DIR = "/path/to/output/yolo_labels"  # 转换后YOLO标签输出目录

    # ================== 执行转换 ==================
    class_map = get_msrs_classes()  # 获取类别映射
    batch_convert_msrs_to_yolo_seg(
        msrs_labels_dir=MSRS_LABELS_DIR,
        output_labels_dir=OUTPUT_LABELS_DIR,
        class_map=class_map,
        min_area=50  # 过滤面积<50的小区域（可根据需求调整）
    )

    print("所有标签转换完成！")