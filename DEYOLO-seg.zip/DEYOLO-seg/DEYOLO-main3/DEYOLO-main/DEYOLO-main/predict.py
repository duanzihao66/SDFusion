from ultralytics import YOLO

import cv2
import numpy as np
import os
import re
model = YOLO(r"D:\新桌面\训练结果\DEA删除depa\weights\best.pt")

results = model.predict([r"D:\DEYOLO-main3\KUST-BSCSD\KUST-BSCSD\images\train_VIS",
                        r"D:\DEYOLO-main3\KUST-BSCSD\KUST-BSCSD\images\train_NIR"], 
                        save=True,
                        #boxes=False,
                        imgsz=640,
                        device='cpu',
                        conf=0.5)

# # 自动递增 masks 文件夹名
# base_dir = "output"
# if not os.path.exists(base_dir):
#     os.makedirs(base_dir)

# existing = [d for d in os.listdir(base_dir) if re.match(r"masks\d+", d)]
# if existing:
#     nums = [int(re.findall(r"\d+", d)[0]) for d in existing]
#     next_num = max(nums) + 1
# else:
#     next_num = 1

# save_dir = os.path.join(base_dir, f"masks{next_num}")
# os.makedirs(save_dir, exist_ok=True)

# def flatten_paths(paths):
#     if isinstance(paths, (list, tuple)):
#         for p in paths:
#             yield from flatten_paths(p)
#     elif isinstance(paths, str):
#         yield paths

# # for i, res in enumerate(results):
# #     img = np.copy(res.orig_img)
# #     if res.masks is not None and len(res.masks.xy) > 0:
# #         b_mask = np.zeros(img.shape[:2], np.uint8)
# #         contour = res.masks.xy[0].astype(np.int32).reshape(-1, 1, 2)
# #         cv2.drawContours(b_mask, [contour], -1, (255, 255, 255), cv2.FILLED)
# #         mask3ch = cv2.cvtColor(b_mask, cv2.COLOR_GRAY2BGR)
# #         isolated = cv2.bitwise_and(mask3ch, img)
# #         for p in flatten_paths(res.path):
# #             orig_name = os.path.basename(p)
# #             save_path = os.path.join(save_dir, f"{os.path.splitext(orig_name)[0]}_mask.png")
# #             cv2.imwrite(save_path, isolated)
# #     else:
# #         print(f"No mask found for image {i}")

# # print(f"Results saved to {save_dir}")
# for i, res in enumerate(results):
#     if res.masks is None or len(res.masks.data) == 0:
#         print(f"No mask found for image {i}")
#         continue

#     h, w = res.orig_img.shape[:2]
#     mask = np.zeros((h, w), dtype=np.uint8)

#     for seg, cls_id in zip(res.masks.data, res.boxes.cls):
#         seg_np = seg.cpu().numpy().astype(np.uint8) * 255  # 转为 0/255
#         seg_resized = cv2.resize(seg_np, (w, h), interpolation=cv2.INTER_NEAREST)  # 还原尺寸
#         mask[seg_resized > 0] = int(cls_id.item()) + 1

#     for p in flatten_paths(res.path):
#         if isinstance(p, str):
#             orig_name = os.path.basename(p)
#             save_path = os.path.join(save_dir, f"{os.path.splitext(orig_name)[0]}.png")
#             cv2.imwrite(save_path, mask)