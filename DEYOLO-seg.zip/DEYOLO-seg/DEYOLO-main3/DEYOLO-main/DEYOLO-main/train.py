from ultralytics import YOLO
import torch


# Load a modelcc
model = YOLO(r"D:\DEYOLO-main3\DEYOLO-main\DEYOLO-main\ultralytics\models\v8\ce.yaml",task='segment')
#model = YOLO(r"D:\DEYOLO-main3\DEYOLO-main\DEYOLO-main\ultralytics\models\v8\DEYOLO-segmish.yaml",task='segment')
# Train the model
s_mode=0



train_results = model.train(
    data=r"D:\DEYOLO-main3\DEYOLO-main\DEYOLO-main\ultralytics\yolo\cfg\KUST-BSCSD.yaml",  # path to dataset YAML
    epochs=1,  # number of training epochs
    imgsz=640,  # training image size
    device="cpu",  # device to run on, i.e. device=0 or device=0,1,2,3 or device=cpu
    batch=1,  # batch size
)
