import torch
import torch.nn as nn
from ultralytics.nn.modules.conv import Conv
class CA_Block(nn.Module):
    def __init__(self, channel, h, w, reduction=16):
        super(CA_Block, self).__init__()

        self.h = h
        self.w = w

        self.avg_pool_x = nn.AdaptiveAvgPool2d((h, 1))
        self.avg_pool_y = nn.AdaptiveAvgPool2d((1, w))

        self.conv_1x1 = nn.Conv2d(in_channels=channel, out_channels=channel//reduction, kernel_size=1, stride=1, bias=False)

        self.relu = nn.ReLU()
        self.bn = nn.BatchNorm2d(channel//reduction)

        self.F_h = nn.Conv2d(in_channels=channel//reduction, out_channels=channel, kernel_size=1, stride=1, bias=False)
        self.F_w = nn.Conv2d(in_channels=channel//reduction, out_channels=channel, kernel_size=1, stride=1, bias=False)

        self.sigmoid_h = nn.Sigmoid()
        self.sigmoid_w = nn.Sigmoid()

    def forward(self, x):

        x_h = self.avg_pool_x(x).permute(0, 1, 3, 2)
        x_w = self.avg_pool_y(x)

        x_cat_conv_relu = self.relu(self.conv_1x1(torch.cat((x_h, x_w), 3)))

        x_cat_conv_split_h, x_cat_conv_split_w = x_cat_conv_relu.split([self.h, self.w], 3)

        s_h = self.sigmoid_h(self.F_h(x_cat_conv_split_h.permute(0, 1, 3, 2)))
        s_w = self.sigmoid_w(self.F_w(x_cat_conv_split_w))

        out = x * s_h.expand_as(x) * s_w.expand_as(x)

        return out
class SPD(nn.Module):
    """
    空间到深度（Space-to-Depth）层
    """
    def __init__(self, block_size=2):
        super(SPD, self).__init__()
        self.block_size = block_size

    def forward(self, x):
        N, C, H, W = x.size()
        block_size = self.block_size
        
        assert H % block_size == 0 and W % block_size == 0, \
            f"空间维度必须能被block_size整除。得到的 H: {H}, W: {W}"
        
        # 空间到深度变换
        x_reshaped = x.view(N, C, H // block_size, block_size, W // block_size, block_size)
        x_permuted = x_reshaped.permute(0, 3, 5, 1, 2, 4).contiguous()
        out = x_permuted.view(N, C * block_size**2, H // block_size, W // block_size)
        return out

class SPDWith1x1(nn.Module):
    """
    简化版本：SPD层 + 1×1卷积
    """
    def __init__(self, in_channels, out_channels, block_size=2):
        super(SPDWith1x1, self).__init__()
        self.spd = SPD(block_size)
        self.conv1x1 = nn.Conv2d(in_channels * block_size**2, out_channels, 1)
    
    def forward(self, x):
        x = self.spd(x)
        x = self.conv1x1(x)
        return x
class SPPF(nn.Module):
    """Spatial Pyramid Pooling - Fast (SPPF) layer for YOLOv5 by Glenn Jocher."""

    def __init__(self, c1, c2, k=5):  # equivalent to SPP(k=(5, 9, 13))
        super().__init__()
        c_ = c1 // 2  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * 4, c2, 1, 1)
        self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)
        self.spd = SPDWith1x1(in_channels=c_, out_channels=c_ * 4, block_size=2)
        self.ca = CA_Block(c_, 1, 1)  # 通道注意力机制
    def forward(self, x):
        """Forward pass through Ghost Convolution block."""
        x = self.spd(x)
        y1 = self.m(x)
        y2 = self.m(y1)
        y3 = torch.cat((x, y1, y2, self.m(y2)), 1)
        y4 = self.spd(y3)
        y4 = self.ca(y4)
        return y4
