import torch
import torch.nn as nn
import math

class ECAAttention(nn.Module):
    """Efficient Channel Attention Module (ECA)
    Paper: https://arxiv.org/abs/1910.03151
    Args:
        channels: 输入特征图的通道数
        gamma: 卷积核大小自适应系数（默认=2）
        beta: 卷积核大小偏移量（默认=1）
    """
    def __init__(self, channels, gamma=2, beta=1):
        super(ECAAttention, self).__init__()
        # 计算一维卷积的核大小（自适应策略）
        kernel_size = int(abs((math.log(channels, 2) + beta) / gamma))
        kernel_size = kernel_size if kernel_size % 2 else kernel_size + 1  # 确保为奇数
        
        # 网络结构
        self.avg_pool = nn.AdaptiveAvgPool2d(1)  # 全局平均池化 [b,c,h,w] -> [b,c,1,1]
        self.conv = nn.Conv1d(1, 1, kernel_size=kernel_size, padding=(kernel_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        b, c, h, w = x.size()
        
        # 1. 通道统计量 [b,c,1,1]
        y = self.avg_pool(x)
        
        # 2. 跨通道交互 [b,c,1,1] -> [b,1,c] -> 1D卷积 -> [b,1,c] -> [b,c,1,1]
        y = y.squeeze(-1).transpose(-1, -2)  # 转置为 [b,1,c]
        y = self.conv(y)                     # 一维卷积捕获邻近通道关系
        y = y.transpose(-1, -2).unsqueeze(-1)  # 恢复形状 [b,c,1,1]
        
        # 3. 生成注意力权重
        y = self.sigmoid(y)
        
        # 4. 按通道加权
        return x * y.expand_as(x)  # 扩展至原特征图尺寸 [b,c,h,w]

