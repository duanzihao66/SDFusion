import torch
import torch.nn as nn
from ultralytics.nn.modules import Conv  # 复用YOLO原生Conv模块

# 1. FMAB基础分支（Specific/Shared分支共用此结构，匹配FMAB结构图）
# 结构：Conv → BN → SiLU → MaxPool
class FMABBranch(nn.Module):
    def __init__(self, c1, c2, k=3, s=2, p=None, pool_size=2):
        super().__init__()
        # 关闭原生Conv的默认激活，手动拆分BN+SiLU（匹配结构图）
        self.conv = Conv(c1, c2, k, s, p, act=False)
        self.bn = nn.BatchNorm2d(c2)  # 批量归一化
        self.act = nn.SiLU()          # SiLU激活
        self.pool = nn.MaxPool2d(kernel_size=pool_size, stride=pool_size)  # 池化层

    def forward(self, x):
        # 前向流程：Conv → BN → SiLU → MaxPool
        x = self.conv(x)
        x = self.bn(x)
        x = self.act(x)
        x = self.pool(x)
        return x

# 2. FMAB主模块（双原始输入→双输出，核心共享权重）
class FMAB(nn.Module):
    def __init__(self, c1, c2, k=3, s=2):
        super().__init__()
        # 初始化3个分支：2个独立Specific + 1个共享Shared
        self.specific_A = FMABBranch(c1, c2, k, s)  # 给backbone的独立分支
        self.shared = FMABBranch(c1, c2, k, s)      # 共享权重核心（关键）
        self.specific_B = FMABBranch(c1, c2, k, s)  # 给backbone2的独立分支

    def forward(self, x):
        # 接收双原始输入：x = (Xa, Xb)（tuple格式）
        Xa, Xb = x
        
        # 各分支处理逻辑
        F_A = self.specific_A(Xa)  # Specific A处理Xa（独立权重）
        F_Sa = self.shared(Xa)     # Shared分支处理Xa（共享权重）
        F_B = self.specific_B(Xb)  # Specific B处理Xb（独立权重）
        F_Sb = self.shared(Xb)     # Shared分支处理Xb（共享权重，同一模块）
        
        # 拼接输出（保证通道=64，匹配原初始Conv(64,3,2)）
        # c2=32 → 32+32=64，与原Conv通道一致
        out1 = torch.cat([F_A, F_Sa], dim=1)  # 输出1：流入backbone
        out2 = torch.cat([F_B, F_Sb], dim=1)  # 输出2：流入backbone2
        return out1, out2

# 3. 输出选择模块（从FMAB双输出中取指定路）
# 作用：backbone取out1（idx=0），backbone2取out2（idx=1）
class SelectOutput(nn.Module):
    def __init__(self, idx):
        super().__init__()
        self.idx = idx  # 0=out1，1=out2

    def forward(self, x):
        # x是FMAB输出的tuple(out1, out2)，取指定索引
        return x[self.idx]