from ultralytics import YOLO
from thop import profile 

import torch
# Load a model
model = YOLO(r"D:\新桌面\训练结果\Branch1+2\best (9).pt") # trained weights


metrics = model.val(
                    data=r"D:\DEYOLO-main3\DEYOLO-main\DEYOLO-main\ultralytics\yolo\cfg\KUST-BSCSD.yaml",
                    split='test',
                    #plots=True,
                    verbose=True,
                    
                    imgsz=640, 
                    device='cpu', 
                    #batch=4,
                    name="run/test" , # save results to 'runs/test',
                    project="runs"  # save results to 'runs/val',
                  )

