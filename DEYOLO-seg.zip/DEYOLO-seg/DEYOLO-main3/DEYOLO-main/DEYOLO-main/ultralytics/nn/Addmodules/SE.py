import torch
import torch.nn as nn

class SEBlock(nn.Module):
    def __init__(self, in_channels, reduction_ratio=16):
        """
        SE注意力模块带残差连接
        Args:
            in_channels: 输入特征图的通道数
            reduction_ratio: 压缩比例
        """
        super(SEBlock, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)  # 全局平均池化
        
        # 安全处理reduction_ratio，避免维度为0
        reduced_channels = max(in_channels // reduction_ratio, 1)
        
        # Excitation操作
        self.fc = nn.Sequential(
            nn.Linear(in_channels, reduced_channels, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(reduced_channels, in_channels, bias=False),
            nn.Sigmoid()  # 输出0~1的权重值
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        
        # Squeeze
        y = self.avg_pool(x).view(b, c)  # [b, c]
        
        # Excitation
        y = self.fc(y).view(b, c, 1, 1)  # [b, c, 1, 1]
        
        # 残差连接: x + x*y
        return x + x * y  # 等价于 x * (1 + y)
