import torch.nn as nn

def autopad(k, p=None, d=1):
    """自动计算padding大小，保持输出尺寸与输入相同（当stride=1时）"""
    if d > 1:
        k = d * (k - 1) + 1  # 实际核大小（考虑膨胀率）
    if p is None:
        p = k // 2  # 自动计算padding
    return p

class Conv9(nn.Module):
    """标准卷积层，参数(ch_in, ch_out, kernel, stride, padding, groups, dilation, activation)"""
    default_act = nn.Mish()  # 默认激活函数设置为Mish

    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        """
        初始化卷积层
        :param c1: 输入通道数
        :param c2: 输出通道数
        :param k: 卷积核大小 (默认为1)
        :param s: 步长 (默认为1)
        :param p: 填充 (默认为None，自动计算)
        :param g: 分组卷积 (默认为1，普通卷积)
        :param d: 膨胀率 (默认为1)
        :param act: 激活函数类型 
                    - True: 使用默认激活函数(Mish)
                    - False: 无激活函数
                    - nn.Module: 使用自定义激活函数
        """
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        
        # 激活函数处理逻辑
        if act is True:
            self.act = self.default_act
        elif isinstance(act, nn.Module):
            self.act = act  # 使用传入的自定义激活函数
        else:
            self.act = nn.Identity()  # 无激活函数

    def forward(self, x):
        """应用卷积、批归一化和激活函数"""
        return self.act(self.bn(self.conv(x)))

    def forward_fuse(self, x):
        """融合卷积和批归一化（用于模型导出）"""
        return self.act(self.conv(x))

# 测试代码
if __name__ == "__main__":
    # 测试1: 默认情况应使用Mish
    conv_default = Conv9(3, 64)
    assert isinstance(conv_default.act, nn.Mish), "默认激活函数应为Mish"
    
    # 测试2: 显式指定True应使用Mish
    conv_true = Conv9(3, 64, act=True)
    assert isinstance(conv_true.act, nn.Mish), "act=True时应使用Mish"
    
    # 测试3: 自定义激活函数
    conv_custom = Conv9(3, 64, act=nn.ReLU())
    assert isinstance(conv_custom.act, nn.ReLU), "应使用自定义ReLU"
    
    # 测试4: 禁用激活函数
    conv_disabled = Conv9(3, 64, act=False)
    assert isinstance(conv_disabled.act, nn.Identity), "应禁用激活函数"
    
    # 测试5: 类默认值修改
    Conv9.default_act = nn.SiLU()
    conv_changed_default = Conv9(3, 64)
    assert isinstance(conv_changed_default.act, nn.SiLU), "修改默认后应使用SiLU"
    
    print("所有测试通过！激活函数配置正确。")